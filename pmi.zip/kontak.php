<?php include('head.php'); ?>
<div class="banner">
<h1 class="deskrippmi" style="width: 170px;">Kontak</h1>
</div>
  <div class="row starter-template2">
    <div class="col-md-7">
      <h1 class="deskrippmi3">Kontak PMI</h1>
        <p class="lead"><b>Alamat :</b> Jl. Imam Bonjol No.182, Pemecutan Klod, Denpasar Barat
		<br/><b>Telepon :</b> (0361) 483465
		<br/><b>Kode Pos :</b> 80113</p>
    </div>
    <div class="col-md-4">
     
    </div>
  </div>
<?php include('footer.php'); ?>