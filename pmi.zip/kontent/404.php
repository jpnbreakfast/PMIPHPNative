<section class="content-header">
     <h1>
        404 Halaman Error
      </h1>
      <ol class="breadcrumb">
        <li class="active fa fa-warning"> 404 error</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="error-page">
        <h2 class="headline text-yellow"> 404</h2>

        <div class="error-content">
          <h3><i class="fa fa-warning text-yellow"></i> Hmmm! Halaman Tidak Ditemukan.</h3>

          <p>
            Sepertinya Halaman yang kamu cari tidak kami temukan.
            Kamu bisa kembali <a href="<?php echo $url;?>admin/">ke halaman Dashboard</a>.
          </p>
        </div>
        <!-- /.error-content -->
      </div>
      <!-- /.error-page -->
    </section>